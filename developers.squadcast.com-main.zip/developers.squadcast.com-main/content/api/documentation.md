---
pcx-content-type: navigation
title: API documentation
weight: 4
---

# API documentation

Go to [apidocs.squadcast.com](https://apidocs.squadcast.com) for documentation of all of Squadcast's API endpoints.
