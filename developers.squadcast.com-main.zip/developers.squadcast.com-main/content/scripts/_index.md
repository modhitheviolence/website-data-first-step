---
title: Scripts
pcx-content-type: tutorial
layout: single
weight: 1
meta:
  title: Scripts
---

# Scripts

We have documented a few scripts that are often asked & used by our users to perform certain actions.