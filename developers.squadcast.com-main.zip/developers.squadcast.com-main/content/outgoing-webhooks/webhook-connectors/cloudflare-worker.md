---
pcx-content-type: navigation
title: Cloudflare worker script
weight: 6
---

# Cloudflare workers based connectors
    
GitHub - https://github.com/SquadcastHub/Squadcast-Cloudflare-Webhook-Connectors

Cloudflare workers help you deploy serverless code instantly across the globe on its edge and we have created a 1-click Deploy with Workers script, which will help you get started quickly. 

### ChatOps
- Slack
- Discord
- Microsoft Teams

### Ticketing
- Trello
